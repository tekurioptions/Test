# The DAG object; we'll need this to instantiate a DAG
from airflow import DAG

# Operators; we need this to operate!
from airflow.operators.bash_operator import BashOperator
# from airflow.operators.docker_operator import DockerOperator

from datetime import datetime, timedelta

# specify default args
default_args = {
    'owner': 'rohail',
    'depends_on_past': False,
    'start_date': datetime.now(),
    'email': ['rohail.taimour@ucb.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

# instantiate class
dag = DAG(
    'g2n', default_args=default_args,
    schedule_interval = timedelta(1)
    )

###############
# specify tasks
###############

# create processed files
t1 = BashOperator(
    task_id='create_processed_files',
    bash_command='R/01_process_data.R',
    dag=dag)

# run model on processed files
# templated_command = """
#     {% for i in range(5) %}
#         echo "{{ ds }}"
#         echo "{{ macros.ds_add(ds, 7) }}"
#         echo "{{ params.my_param }}"
#     {% endfor %}
# """
# 
# t2 = BashOperator(
#     task_id='templated',
#     bash_command=templated_command,
#     params={'my_param': 'Parameter I passed in'},
#     dag=dag)

t2 = BashOperator(
  task_id='run_model',
  bash_command='R/02_run_model.R',
  dag=dag
)

# generate reports
t3 = BashOperator(
  task_id='create_report',
  bash_command='R/03_create_report.R',
  dag=dag
)

# setup linear dependencies

t2.set_upstream(t1)

# This means that t2 will depend on t1
# running successfully to run
# It is equivalent to
# t1.set_downstream(t2)

t3.set_upstream(t2)
