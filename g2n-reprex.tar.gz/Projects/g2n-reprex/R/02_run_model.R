#!/usr/bin/env Rscript
library(dplyr)
library(futile.logger)

processed_data_dir <- "./RESOURCES/processed_data"
log_file_dir <- "./RESOURCES/model_logs"
write_out_dir <- "./RESOURCES/model_rds"

data_file_names <- list.files(processed_data_dir)
data_file_dirs <- file.path(processed_data_dir, data_file_names)

logger_name <- 'my_logger'
# specify the log file name according to user
log_file_out <- file.path(log_file_dir,
                           paste0(as.character(Sys.info()['user']),
                                  format(Sys.time(),'_%Y-%b-%d_%HH%M'),
                                  '.log')
)
# create the file
invisible(file.create(log_file_out))

# set the logger threshold
invisible(futile.logger::flog.threshold(INFO))


# create appender for log
invisible(
  futile.logger::flog.appender(
    futile.logger::appender.file(log_file_out),
    name = logger_name
  )
)  

flog.info("Starting", name = logger_name)

doMC::registerDoMC(min(3, length(data_file_dirs)))

out <- parallel::mclapply(data_file_dirs, function(f) {
  
  # add sleep otherwise too fast
  Sys.sleep(10)
  # read file
  df <- read.csv(f)
  df
})

model_name <- gsub(pattern = ".log", replacement = ".rds",
                   x = basename(log_file_out))
# write to disk
saveRDS(object = out, 
        file = file.path(write_out_dir,
                         model_name))

flog.info("Finished", name = logger_name)
