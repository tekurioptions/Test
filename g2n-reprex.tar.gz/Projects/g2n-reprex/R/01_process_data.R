#!/usr/bin/env Rscript
library(dplyr)

data_dir <- "./DATA"
data_file_names <- list.files(data_dir)
write_out_dir <- "./RESOURCES/processed_data"
for (f in data_file_names) {
  # read file
  df <- read.csv(file.path(data_dir,f))
  # remove column
  df <- dplyr::select(df, -Species)
  # write to disk
  write.csv(x = df,
            file = file.path(write_out_dir,
                             paste0("processed_", f)),
            row.names = F)
}


