#!/usr/bin/env Rscript
library(rmarkdown)

template_dir <- "./R"
report_dir <- "../REPORTS/"

# render report 
report_output_dir <- 
  file.path(report_dir,
            "test_report.html")

# create name of the report
rmarkdown::render(input = file.path(template_dir,
                                    'test.Rmd'),
                  quiet = TRUE,
                  output_file = report_output_dir
)
